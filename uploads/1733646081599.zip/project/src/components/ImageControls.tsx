import React from 'react';
import { Crop, RotateCw, FlipHorizontal, Download } from 'lucide-react';

interface ImageControlsProps {
  onRotate: () => void;
  onFlip: () => void;
  onCrop: () => void;
  onDownload: () => void;
  isCropping: boolean;
}

const ImageControls: React.FC<ImageControlsProps> = ({
  onRotate,
  onFlip,
  onCrop,
  onDownload,
  isCropping
}) => {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-2">
        <button
          onClick={onCrop}
          className={`flex-1 py-2 px-4 rounded-lg flex items-center justify-center ${
            isCropping 
              ? 'bg-blue-600 text-white hover:bg-blue-700' 
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
        >
          <Crop className="mr-2" size={20} /> {isCropping ? 'Apply Crop' : 'Crop'}
        </button>
        <button
          onClick={onRotate}
          className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 py-2 px-4 rounded-lg flex items-center justify-center"
        >
          <RotateCw className="mr-2" size={20} /> Rotate
        </button>
        <button
          onClick={onFlip}
          className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 py-2 px-4 rounded-lg flex items-center justify-center"
        >
          <FlipHorizontal className="mr-2" size={20} /> Flip
        </button>
        <button
          onClick={onDownload}
          className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg flex items-center justify-center"
        >
          <Download className="mr-2" size={20} /> Save
        </button>
      </div>
    </div>
  );
};

export default ImageControls;