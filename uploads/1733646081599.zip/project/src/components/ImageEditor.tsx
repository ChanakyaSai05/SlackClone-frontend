import React, { useState, useCallback } from 'react';
import Cropper from 'react-easy-crop';
import { useDropzone } from 'react-dropzone';
import { Image as ImageIcon } from 'lucide-react';
import { ImageState } from '../types';
import { getCroppedImg, createImage } from '../utils/imageUtils';
import FilterControls from './FilterControls';
import ImageControls from './ImageControls';

const ImageEditor: React.FC = () => {
  const [image, setImage] = useState<string>('');
  const [crop, setCrop] = useState({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(1);
  const [rotation, setRotation] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [croppedAreaPixels, setCroppedAreaPixels] = useState<any>(null);
  const [isCropping, setIsCropping] = useState(false);
  const [filters, setFilters] = useState<ImageState>({
    brightness: 100,
    contrast: 100,
    saturation: 100,
    blur: 0,
    sepia: 0,
    grayscale: 0
  });

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    const imageUrl = URL.createObjectURL(file);
    setImage(imageUrl);
    // Reset all states when new image is uploaded
    setCrop({ x: 0, y: 0 });
    setZoom(1);
    setRotation(0);
    setFlipped(false);
    setIsCropping(false);
    setFilters({
      brightness: 100,
      contrast: 100,
      saturation: 100,
      blur: 0,
      sepia: 0,
      grayscale: 0
    });
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { 'image/*': [] },
    multiple: false
  });

  const onCropComplete = useCallback((croppedArea: any, croppedAreaPixels: any) => {
    setCroppedAreaPixels(croppedAreaPixels);
  }, []);

  const handleFilterChange = (filter: keyof ImageState, value: number) => {
    setFilters(prev => ({ ...prev, [filter]: value }));
  };

  const getFilterStyle = () => {
    const filterString = `brightness(${filters.brightness}%) 
                         contrast(${filters.contrast}%) 
                         saturate(${filters.saturation}%) 
                         blur(${filters.blur}px) 
                         sepia(${filters.sepia}%) 
                         grayscale(${filters.grayscale}%)`;
    return {
      filter: filterString,
      transform: `scaleX(${flipped ? -1 : 1})`
    };
  };

  const handleCrop = async () => {
    if (isCropping && croppedAreaPixels) {
      try {
        const croppedImage = await getCroppedImg(
          image,
          croppedAreaPixels,
          rotation,
          { horizontal: flipped, vertical: false }
        );
        setImage(croppedImage);
        setIsCropping(false);
        setCrop({ x: 0, y: 0 });
        setZoom(1);
      } catch (e) {
        console.error('Error cropping image:', e);
      }
    } else {
      setIsCropping(true);
    }
  };

  const handleDownload = async () => {
    try {
      const img = await createImage(image);
      const canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext('2d');
      
      if (ctx) {
        ctx.filter = getFilterStyle().filter;
        ctx.save();
        ctx.translate(canvas.width / 2, canvas.height / 2);
        ctx.rotate((rotation * Math.PI) / 180);
        ctx.scale(flipped ? -1 : 1, 1);
        ctx.translate(-canvas.width / 2, -canvas.height / 2);
        ctx.drawImage(img, 0, 0);
        ctx.restore();
        
        const link = document.createElement('a');
        link.download = 'edited-image.jpg';
        link.href = canvas.toDataURL('image/jpeg', 0.9);
        link.click();
      }
    } catch (error) {
      console.error('Error downloading image:', error);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-6xl mx-auto bg-white rounded-xl shadow-lg overflow-hidden">
        <div className="p-6">
          <h1 className="text-3xl font-bold text-gray-800 mb-8 flex items-center">
            <ImageIcon className="mr-2" /> Photo Editor
          </h1>

          {!image ? (
            <div
              {...getRootProps()}
              className={`border-2 border-dashed rounded-lg p-12 text-center cursor-pointer transition-colors
                ${isDragActive ? 'border-blue-500 bg-blue-50' : 'border-gray-300 hover:border-gray-400'}`}
            >
              <input {...getInputProps()} />
              <p className="text-lg text-gray-600">
                Drag & drop an image here, or click to select
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 relative h-[500px] bg-gray-100 rounded-lg overflow-hidden">
                {isCropping ? (
                  <Cropper
                    image={image}
                    crop={crop}
                    zoom={zoom}
                    rotation={rotation}
                    aspect={4 / 3}
                    onCropChange={setCrop}
                    onZoomChange={setZoom}
                    onCropComplete={onCropComplete}
                    showGrid
                  />
                ) : (
                  <div className="w-full h-full relative">
                    <img
                      src={image}
                      alt="Edited"
                      className="absolute inset-0 w-full h-full object-contain"
                      style={{
                        ...getFilterStyle(),
                        transform: `${getFilterStyle().transform} rotate(${rotation}deg)`
                      }}
                    />
                  </div>
                )}
              </div>

              <div className="space-y-6">
                <ImageControls
                  onRotate={() => setRotation((r) => (r + 90) % 360)}
                  onFlip={() => setFlipped((f) => !f)}
                  onCrop={handleCrop}
                  onDownload={handleDownload}
                  isCropping={isCropping}
                />
                <FilterControls
                  filters={filters}
                  onFilterChange={handleFilterChange}
                />
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ImageEditor;