import React from 'react';
import { Sliders } from 'lucide-react';
import { Filter, ImageState } from '../types';

interface FilterControlsProps {
  filters: ImageState;
  onFilterChange: (filter: keyof ImageState, value: number) => void;
}

const FilterControls: React.FC<FilterControlsProps> = ({ filters, onFilterChange }) => {
  const filterControls: Filter[] = [
    { name: 'Brightness', value: filters.brightness, min: 0, max: 200, step: 1 },
    { name: 'Contrast', value: filters.contrast, min: 0, max: 200, step: 1 },
    { name: 'Saturation', value: filters.saturation, min: 0, max: 200, step: 1 },
    { name: 'Blur', value: filters.blur, min: 0, max: 20, step: 0.1 },
    { name: 'Sepia', value: filters.sepia, min: 0, max: 100, step: 1 },
    { name: 'Grayscale', value: filters.grayscale, min: 0, max: 100, step: 1 }
  ];

  return (
    <div className="bg-gray-50 p-4 rounded-lg">
      <h3 className="text-lg font-semibold mb-4 flex items-center">
        <Sliders className="mr-2" /> Adjustments
      </h3>
      {filterControls.map((filter) => (
        <div key={filter.name} className="mb-4">
          <label className="text-sm text-gray-600 block mb-2">
            {filter.name}: {filter.value}
          </label>
          <input
            type="range"
            min={filter.min}
            max={filter.max}
            step={filter.step}
            value={filter.value}
            onChange={(e) => onFilterChange(filter.name.toLowerCase() as keyof ImageState, parseFloat(e.target.value))}
            className="w-full h-2 bg-blue-100 rounded-lg appearance-none cursor-pointer"
          />
        </div>
      ))}
    </div>
  );
};

export default FilterControls;