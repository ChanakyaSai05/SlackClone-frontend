export interface Filter {
  name: string;
  value: number;
  min: number;
  max: number;
  step: number;
}

export interface ImageState {
  brightness: number;
  contrast: number;
  saturation: number;
  blur: number;
  sepia: number;
  grayscale: number;
}